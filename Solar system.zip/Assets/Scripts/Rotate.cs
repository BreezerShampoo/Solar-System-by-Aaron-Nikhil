using UnityEngine;

public class Rotate : MonoBehaviour
{
    // Declare a variable to select the rotation target
    public Transform target;

    // Speed of rotation (degrees per second)
    public float speed = 10f;

    // Update is called once per frame
    void Update()
    {
        if (target != null)
        {
            // Rotate this object around the target's position
            // Axis is the up vector (Vector3.up or target.up)
            transform.RotateAround(target.position, Vector3.up, speed * Time.deltaTime);
        }
    }
}
